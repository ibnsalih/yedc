-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2020 at 07:45 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `electric`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE IF NOT EXISTS `bill` (
  `Username` varchar(30) NOT NULL,
  `bill_no` int(30) NOT NULL,
  `month` varchar(30) NOT NULL,
  `expiry_date` varchar(100) NOT NULL,
  `unit_consumed` int(30) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'unpaid'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`Username`, `bill_no`, `month`, `expiry_date`, `unit_consumed`, `status`) VALUES
('chandan1', 111, 'March', '', 1000, 'paid'),
('chandan1', 123, 'March', '', 200, 'paid'),
('chandan1', 444, 'volvo', '', 1110, 'paid'),
('chandan1', 123456, 'May', '', 500, 'paid'),
('chandan1', 1111, 'March', '', 100, 'paid'),
('chandan1', 1112, 'January', '', 900, 'paid'),
('dhruv1', 1234, 'February', '', 2000, 'paid'),
('chandan1', 111, 'February', '', 20, 'paid'),
('ibnsalih', 123456, 'February', '', 200, 'unpaid');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `name` varchar(30) NOT NULL,
  `mobile_No` bigint(20) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `feedback` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `mobile_No`, `Email`, `feedback`) VALUES
('chandan', 777777777, 'tiwarichandan64@gmail.com', 'Nice'),
('dhruvhgds', 9648233550, 'z@w', 'dfghjkm,.');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
`uid` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `mobile_No` int(10) NOT NULL,
  `name` varchar(19) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `feedback` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`uid`, `username`, `password`, `mobile_No`, `name`, `Email`, `address`, `feedback`) VALUES
(10, 'ibnsalih', 'bangis', 2147483647, 'Babangida Salihu Ad', 'ibnsalih112@gmail.com', 'Railway Road Bauchi', ''),
(11, 'tasiu', 'tasiu', 2147483647, 'Tasi u Idris', 'tasiuzaheed1993@gmail.com', 'Railway Road Bauchi', '');

-- --------------------------------------------------------

--
-- Table structure for table `update_cost`
--

CREATE TABLE IF NOT EXISTS `update_cost` (
  `cost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `update_cost`
--

INSERT INTO `update_cost` (`cost`) VALUES
(2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
 ADD PRIMARY KEY (`uid`), ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
