<script type="text/javascript">
     $(document).ready(function(){
    $('#example').dataTable();
});
   </script>